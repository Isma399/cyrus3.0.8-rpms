/*
 * variables.h
 *
 *  Created on: Dec 26, 2014
 *      Author: James Cassell
 */

#ifndef SIEVE_VARIABLES_H_
#define SIEVE_VARIABLES_H_

char *variables_modify_string (const char *string, int modifiers);

#endif /* SIEVE_VARIABLES_H_ */
